#!/bin/bash

root_dir="$1"

mkdir -p $root_dir

mkdir -p $root_dir/css 
mkdir -p $root_dir/assets
mkdir -p $root_dir/assets/images
mkdir -p $root_dir/assets/videos


touch $root_dir/css/app.css

echo "* {" >> $root_dir/css/app.css
echo "  margin: 5px;" >> $root_dir/css/app.css
echo "  padding: 0;" >> $root_dir/css/app.css
echo "  box-sizing: border-box;" >> $root_dir/css/app.css
echo "  scroll-behavior: smooth;" >> $root_dir/css/app.css

echo "}" >> $root_dir/css/app.css


index=index.html
touch $root_dir/$index

echo "<!DOCTYPE html>" >> $root_dir/$index
echo "<html lang='en'>" >> $root_dir/$index
echo >> $root_dir/$index 
echo "<body>" >> $root_dir/$index

echo " <h1>About</h1>" >> $root_dir/$index
echo " <p>
        In 2020, Dsl Dealer a new car dealership was established that offered a unique approach to the automotive industry. This dealership, 
        which sold all brands of cars and provided all types of maintenance services, aimed to provide customers with the best prices in the market while delivering exceptional service and quality.

        The founders of this dealership were experienced professionals in the automotive industry who had previously worked for other companies. 
        They brought their expertise and knowledge to the new dealership, creating a team of highly skilled and knowledgeable staff.

        From the outset, the new dealership offered a comprehensive range of services, including sales, leasing, financing, repairs, maintenance, and parts sales. 
        They recognized that customers were looking for a one-stop-shop where they could buy a car, have it serviced, and get all their automotive needs met in one place.

        The dealership focused on building strong relationships with their customers and providing personalized service that went above and beyond their expectations. 
        They listened to their customers' needs and worked hard to provide them with the best options to suit their budgets and preferences.

        To stay ahead of the competition, the dealership leveraged the latest technologies to streamline their operations and improve customer experiences. 
        They invested in advanced diagnostic equipment, which enabled them to identify and resolve any issues with customers' vehicles quickly and efficiently. 
        They also offered online booking for service appointments and provided customers with access to their repair histories and service records.

        Despite the challenges posed by the COVID-19 pandemic, the dealership remained committed to delivering exceptional service to its customers. 
        They implemented stringent health and safety protocols to ensure the safety of their staff and customers while continuing to provide their services.

        Over time, the dealership became known for its outstanding customer service, quality workmanship, and competitive prices.
        It attracted a loyal customer base, and its reputation grew rapidly, making it one of the most successful dealerships in the area.

        In conclusion, the new car dealership established in 2020 proved to be a game-changer in the automotive industry. 
        By offering all brands of cars and providing all types of maintenance services, they created a one-stop-shop for customers looking for convenience and quality. 
        Their focus on personalized service, the latest technology, and competitive pricing ensured their success and established them as a trusted and reliable dealership in the market.
        </p>" >> $root_dir/$index

echo " <footer>
             &copy; Dsl Dealer.  All rights reserved.
      </footer>" >> $root_dir/$index 
echo "</body>" >> $root_dir/$index

echo " <style> 
        
        body {
            text-align: center;
            border: 1px solid black;
            background-color: navy;
            color: blue;
            font-family:"Lucida Console", "Courier New", monospace;
            }

            h1 {
                  font-size: 4rem;
                  background-color: silver;
                  font-family: "Rockwell", monospace;
                  font-style: italic;
                  text-align: center;
                  margin-top: 40px;
                  margin-bottom: 40px;
                  }
        
        p {
            color: blue;
            text-align: justify;
            margin: 150px 150px;
            margin-top: 30px;
            margin-bottom: 30px;
            }

          footer {
            color: white;
            text-align: center;
            margin-top: 30px;
            margin-bottom: 30px;

      }




          </style>" >> $root_dir/$index


#-----------------------------------------------------------

index=services.html
touch $root_dir/$index

echo "<!DOCTYPE html>" >> $root_dir/$index
echo "<html lang='en'>" >> $root_dir/$index
echo >> $root_dir/$index 
echo "<body>" >> $root_dir/$index

echo " <h1>Services</h1>" >> $root_dir/$index

echo "  <img src='assets/images/m.jpg' alt='m' />" >> $root_dir/$index
echo " <p>
        Dsl Dealer offer a range of services to customers, including sales, financing, service, parts, trade-ins, test drives, warranties, insurance, extended warranties, and accessories. 
        Sales involve the sale of new and used vehicles, while financing options include both loans and leasing arrangements. 
        Service and parts departments provide maintenance, repair, and replacement of vehicle components. 
        Trade-ins allow customers to exchange their existing vehicle for a new one, and test drives provide an opportunity for customers to experience a vehicle before making a purchase. 
        Warranties and extended warranties offer peace of mind to customers, and insurance policies provide protection for their vehicles. 
        Finally, dealerships often offer a range of accessories and upgrades to personalize and enhance the customer's driving experience.

       </p>"  >> $root_dir/$index

echo " <footer>
             &copy; Dsl Dealer.  All rights reserved.
      </footer>" >> $root_dir/$index 

 echo "</body>" >> $root_dir/$index     

echo " <style> 
        
        body {
            border: 1px solid black;
            background-color: navy;
            color: blue;
            font-family:"Lucida Console", "Courier New", monospace;
            }

            h1 {
                  font-size: 4rem;
                  background-color: silver;
                  font-family: "Rockwell", monospace;
                  font-style: italic;
                  text-align: center;
                  margin-top: 50px;
                  margin-bottom: 50px;
      }
        
             img {
                  display: block;
                  margin: 0 auto;
                  }
       
         p {
            color: blue;
            text-align: justify;
            margin: 150px 150px;
            margin-top: 50px;
            margin-bottom: 50px;
          }

         footer {
            color: white;
            text-align: center;
            margin-top: 30px;
            margin-bottom: 30px;

      } 




          </style>" >> $root_dir/$index


#--------------------------------------------------------------------------------

index=contact.html
touch $root_dir/$index
echo "<!DOCTYPE html>" >> $root_dir/$index
echo "<html lang='en'>" >> $root_dir/$index
echo >> $root_dir/$index
echo "<body>" >> $root_dir/$index
echo "<h1>Contact<h1>" >> $root_dir/$index

echo "   <form method="post" action="https://webdevbasics.net/scripts/demo.php">
                <label for="myName">Name:</label>
                <input type="text" name="myName" id="myName" />
                <label for="myEmail">Email:</label>
                <input type="email" name="myEmail" id="myEmail" />
                <label for="myComments">Comments:</label>
                <textarea name="myComments" id="myComments" rows="2" cols="20"></textarea> 
                <input type="submit" id="mySubmit" value="Submit" />
                <input type="reset" id="myReset" value="Reset" />
            </form>" >> $root_dir/$index
echo "      <ul>
                <li>
                    E-mail: <a href="mailto:contact@dlsdealer.com">
                        contact@dlsdealer.com
                    </a>
                </li>
                <li>
                    Phone: 111-895-9556
                </li>
            </ul>" >> $root_dir/$index




 echo " <footer>
             &copy; Dsl Dealer.  All rights reserved.
      </footer>" >> $root_dir/$index           

echo "</body>" >> $root_dir/$index

echo " <style>
           


        body {

            border: 1px solid black;
            background-color: navy;
            color: blue;
            font-family:"Lucida Console", "Courier New", monospace;
            padding: 15px;
            }
            

              
            
         </style>"     >> $root_dir/$index
         

#--------------------------------------------------------------------------





index=home.html
touch $root_dir/$index

echo "<!DOCTYPE html>" >> $root_dir/$index
echo "<html lang='en'>" >> $root_dir/$index
echo >> $root_dir/$index 

echo "<head>" >> $root_dir/$index
echo "<link href='css/app.css' rel='stylesheet' type='text/css' />" >> $root_dir/$index
echo "</head>" >> $root_dir/$index

echo "<style>
  body {
    border: 1px solid black;
    background-color: navy;
  }
</style>" >> $root_dir/$index

echo "<style>
  body {
    text-align: center;
  }
</style>" >> $root_dir/$index

echo "<style>

          nav ul {
                  background: navy;
                  list-style: none;
                  margin: 0;
                  padding: 0;
                  }

            nav li {
                      display: inline-block;
              }

            nav li a {
                      font-family: "Lucida Console", "Courier New", monospace;
                      font-size: 2rem;
                      display: block;
                      padding: 10px;
                      text-decoration: none;
                      color: blue;

                    }

            nav li a:hover {
                            background-color: orange;
                            }
      
      img {
       display: block;
       margin: 0 auto;
      }

      h1 {
        font-size: 2rem;
         background-color: silver;
         color: blue;
         margin-top: 40px;
         margin-bottom: 40px;
      }
      
      h3 {
          font-size: 2rem;
          background-color: silver;
          color: blue;
          margin-top: 40px;
          margin-bottom: 40px;
      }

      h4 {
          font-family: "Rockwell", monospace;
          font-style: italic;
          font-size: 6rem;
          color: silver;
          margin-bottom: 30px;
          font-weight: bold;
          text-shadow: 7px 7px 9px gray;
          animation-name: changeColor;
          animation-duration: 6s;
          animation-iteration-count: infinite;
          }

          @keyframes changeColor {
            0% {
            color: green;
               }
            50% {
          color: purple;
          }
          100% {
          color: red;
               }
          
        }

        h5 {
           font-size: 2rem;
           background-color: silver;
           color: blue;
           margin-top: 40px;
           margin-bottom: 40px;
           }
    

      h6 {
           font-size: 2rem;
           background-color: silver;
           color: blue;
           margin-top: 40px;
           margin-bottom: 40px;
      }
      
      p {
        font-family: "Lucida Console", "Courier New", monospace;
        color: blue;
        text-align: justify;
        margin: 150px 150px;
        margin-top: 30px;
        margin-bottom: 30px;

      }


      footer {
            color: white;
            text-align: center;
            margin-top: 30px;
            margin-bottom: 30px;

      }

    </style>" >> $root_dir/$index
     

echo >> $root_dir/$index # blank line
echo "<body>" >> $root_dir/$index
echo " <h4>DLS Dealer</h4>" >> $root_dir/$index

echo " <nav>
          <ul>
              <li><a href="index.html">About</a></li>
              <li><a href="services.html">Services</a></li>
              <li><a href="contact.html">Contact</a></li>
          </ul>
</nav>" >> $root_dir/$index


echo "  <img src='assets/images/truck.jpg' alt='truck' />" >> $root_dir/$index 

echo "  <h1>Chevrolet Silverado</h1>" >> $root_dir/$index
echo "  <p> 
          The 2023 Chevrolet Silverado is an upcoming full-size pickup truck that promises to be one of the most capable and refined trucks in its class. 
          It will be available with a variety of powertrain options, including a new hybrid system that is expected to deliver impressive fuel efficiency without sacrificing performance. 
          The exterior of the Silverado has been updated with a more aggressive grille and new lighting elements, while the interior will feature a range of high-tech features and premium materials. 
          The Silverado will also come equipped with a range of advanced safety features, making it one of the safest trucks on the market. With its combination of power, capability, and refinement, 
          the 2023 Chevrolet Silverado is sure to be a hit with truck enthusiasts and casual drivers alike.
        </p>" >> $root_dir/$index

echo "  <img src='assets/images/silve.jpg' alt='silve' />" >> $root_dir/$index  
echo "  <h3>Corvette c8</h3>" >> $root_dir/$index
echo "  <p>
        The 2023 Chevrolet Corvette is the latest version of the iconic American sports car, and it promises to be one of the most impressive Corvettes yet. 
        It will be available in both coupe and convertible body styles, and will feature a range of high-performance engines, 
        including a new twin-turbo V8 that is expected to deliver up to 800 horsepower. 
        The Corvette's exterior has been updated with a more aggressive front fascia and new lighting elements, while the interior will feature a range of premium materials and high-tech features, 
        including a large touchscreen display and a digital instrument cluster. The Corvette will also come equipped with a range of advanced safety features, including automatic emergency braking and lane departure warning, 
        making it one of the safest sports cars on the market. With its combination of power, style, and technology, the 2023 Chevrolet Corvette is sure to be a favorite among sports car enthusiasts.
        </p>" >> $root_dir/$index
echo >> $root_dir/$index # blank line        
echo >> $root_dir/$index # blank line
 echo "  <p>
        Chevrolet is an American automotive brand that has been around since 1911. Over the years, 
        Chevrolet has become known for producing a wide range of vehicles, from sports cars and muscle cars to pickup trucks and SUVs. 
        One of the most iconic Chevrolet models is the Corvette, a two-seat sports car that has been in production since 1953. 
        In addition to the Corvette, Chevrolet also produces popular models such as the Silverado pickup truck, the Equinox SUV, 
        and the Malibu midsize sedan. 
        With a reputation for reliability and performance, Chevrolet continues to be a favorite among American car buyers.
        </p>" >> $root_dir/$index

 echo "  <img src='assets/images/cor.jpg' alt='cor' />" >> $root_dir/$index  

 echo "  <h5>Ford 150 Raptor</h5>"  >> $root_dir/$index

 echo "  <p>
       The Ford F-150 is a full-size pickup truck that was redesigned for the 2021 model year, and the 2022 Ford F-150 continues to build upon that success. 
       With a range of powerful and efficient engine options, including a hybrid powertrain, the F-150 offers impressive towing and hauling capabilities, making it a versatile workhorse for both personal and commercial use. 
       The F-150 also boasts a comfortable and spacious cabin with advanced technology features, such as the SYNC 4 infotainment system, available Apple CarPlay and Android Auto, and a range of driver-assistance features like adaptive cruise control, 
       lane-keeping assist, and automatic emergency braking. 
       Overall, the 2022 Ford F-150 remains a top contender in the highly competitive pickup truck market
      </p>" >> $root_dir/$index

echo "  <img src='assets/images/ford.jpg' alt='ford' />" >> $root_dir/$index  

echo "  <h6>Ford Bronco</h6>"  >> $root_dir/$index
echo "  <p>
       The Ford Bronco is an iconic SUV that has been redesigned for the 2021 model year, and the 2022 Ford Bronco continues to impress with its rugged off-road capabilities and modern technology features. 
       With two body styles (two-door and four-door), seven trim levels, and a range of available accessories, the Bronco offers customization options to suit a variety of lifestyles and preferences. 
       The Bronco is built on a rugged body-on-frame platform and is available with a range of powerful engines, including a turbocharged four-cylinder and a twin-turbocharged V6. It also offers advanced off-road features like electronic locking differentials, disconnecting sway bars, and up to 11.6 inches of ground clearance, making it a formidable off-road machine. 
       Inside, the Bronco features a modern and functional cabin with an available 12-inch infotainment touchscreen, Apple CarPlay and Android Auto integration, and a range of driver-assistance features like blind-spot monitoring and adaptive cruise control. Overall, the 2022 Ford Bronco is a highly capable and versatile SUV that is sure to please both off-road enthusiasts and daily drivers alike.
      </p>" >> $root_dir/$index
 
echo "  <img src='assets/images/bronco1.jpg' alt='bronco1' />" >> $root_dir/$index


echo "</body>" >> $root_dir/$index

echo " <footer>
             &copy; Dsl Dealer.  All rights reserved.
      </footer>" >> $root_dir/$index




cp ~/CHEVROLET_PROJECT/images/silve.jpg $root_dir/assets/images/silve.jpg

cp ~/CHEVROLET_PROJECT/images/cor.jpg $root_dir/assets/images/cor.jpg

cp ~/CHEVROLET_PROJECT/images/truck.jpg $root_dir/assets/images/truck.jpg

cp ~/CHEVROLET_PROJECT/images/ford.jpg $root_dir/assets/images/ford.jpg

cp ~/CHEVROLET_PROJECT/images/bronco1.jpg $root_dir/assets/images/bronco1.jpg

cp ~/CHEVROLET_PROJECT/images/m.jpg $root_dir/assets/images/m.jpg

echo "final"